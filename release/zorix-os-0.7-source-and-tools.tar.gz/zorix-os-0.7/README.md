# Zorix OS 0.7 - Glass Live Experimental

This release includes a standalone x86-64 UEFI Live ISO, not merely a theme,
not an ISO containing only source code, and not a network bootstrap image.
It contains its kernel, compressed RAM root filesystem, Swift runtime,
Chromium/X11 desktop and the earlier Zorix user-space tools.

**Firmware boot and boot-to-desktop have NOT been tested. There is no disk
installer, no persistent storage, no Secure Boot signature, and no claim of
production readiness. Use an isolated disposable VM, without an internal disk,
shared folders, sensitive accounts or automatic network access.**

## Start with a disposable VM

Use x86-64 UEFI firmware, the ISO as a virtual optical drive, and a conventional
EFI/GOP framebuffer. A suggested TEST allocation is 8 GiB RAM and 4 vCPUs;
this is not a measured minimum. Legacy BIOS and ARM are not implemented.
The loader is unsigned: use a test VM configured for unsigned UEFI images.
Do not change your primary computer's security settings to try this image.

Boot menu:
1. Portable software display: default, EFI framebuffer + Xvfb mirror.
2. Native KMS display: experimental fallback path, NOT validated.
3. Recovery console: root console in the disposable Live environment.

The default session is user `zorix`, with locked password records and no
reusable root password. Only the exact reboot/poweroff helper is sudo-allowed.
The Live root, notes, downloads and settings reside in RAM and disappear when
the VM powers off. Internal disks are not automatically mounted. No installer
is present: this image does not turn a blank hard disk into an installed OS.

A real test on a host with QEMU/OVMF could use:

```sh
qemu-system-x86_64 -machine q35 -m 8192 -smp 4 \
  -bios /path/to/OVMF_CODE.fd \
  -cdrom zorix-os-0.7-liquid-glass-amd64.iso -boot d \
  -vga std -nic none
```

That example has NOT been executed here. Some OVMF builds require separate
CODE/VARS pflash drives; use a private writable copy of the matching VARS file.
The portable display path needs EFI framebuffer exposure. If the desktop does
not appear, use the recovery menu and inspect `/var/log/zorix` and
`/home/zorix/.config/zorix/*.log`. The image may require boot/display fixes.

## What is actually original

- C UEFI application (`BOOTX64.EFI`) with menu, logo and Linux LoadFile2 initrd
  delivery. It delegates OS loading and hardware control to the Linux EFI stub.
- Static C PID 1 and small C framebuffer/input/power helpers.
- Swift 6.2.1-compiled read-only system information component, `zorix-core`.
- Glass-style desktop UI, Dock, app search, welcome, settings, file browser,
  real notes with save/export, arithmetic parser, focus timer and calendar.
- Local Python broker with per-session token, Host/Origin checks, home-confined
  file API, explicit power confirmations and allowlisted application launching.
- Original geometric glyph-generation code creates a runtime UI face during
  boot. No installed system font files are included in this delivery.
- Original early-boot spinner renderer; rendering preview is not proof of boot.
- ISO/FAT32/newc packaging and independent structural audit tools.

The kernel is unmodified Debian `6.12.96+deb13-amd64`, not a new Zorix kernel.
Most operating-system facilities are Debian/Linux, Chromium, X11 and Openbox.
The desktop surface is HTML/CSS/JavaScript; Swift supplies a small real system
component, not the entire desktop. No Apple SwiftUI, UIKit, AppKit or Apple
Liquid Glass implementation is included. The visual treatment is original,
inspired by translucent glass. Gabriele Aeng is credited for project design.

## User-visible tools

Glass Dock, app search (Ctrl+K), Files with folder navigation/creation and full
legacy manager, Notes, Calculator, Focus Space, Calendar, settings with three
themes and reduced-motion/transparency/contrast controls, Control Center,
Swift-backed system view, browser launcher and welcome guide.

Earlier tools retained: Zorix Files/Terminal/AI client, ZPK/.zorix utilities,
Windows/Wine manager, GPU/RTX manager, component import, diagnostics and rollback.
**Wine, DXVK, VKD3D-Proton, DXVK-NVAPI, NVIDIA proprietary drivers, AI model
weights, firmware and a Wi-Fi manager are not bundled.** These managers are not
proof that a Windows application, ray tracing, DLSS or a game will run.
The default ISO desktop is CPU-rendered and is not an RTX gaming environment.

The interface is primarily English, with a basic US keyboard layout. The
language preference field is reserved; it is not a complete Italian/Chinese
translation. No gesture system, unified native glass window decoration,
Bluetooth stack UI, audio mixer or production login manager is claimed.

## Verification boundaries

Read `docs/VERIFICATION.json` for the final result. UI screenshots show the
real code rendered off-line in host Chromium, with Python transporting actual
loopback API calls because the host managed browser blocks local navigation.
They are **not screenshots of this ISO booting**. The managed browser policy
was kept intact. Only the root TEST HARNESS used Chromium `--no-sandbox`;
the Live launch path uses the ordinary user's browser sandbox and no fallback.

Protocol mocks, chroot CLI tests and structural checks do not validate real
firmware, GPU/keyboard/mouse devices, networking, Secure Boot or persistence.
No old test totals were copied into the new release's pass count.

## Source and rebuilding

`src/`, `ui/`, `Makefile`, `tools/` and `tests/` contain the new implementation.
`vendor/zorix-custom-0.4` contains the preserved earlier component packages and
sources. The ISO also carries Zorix source under `/usr/share/doc/zorix-os`.

`make` rebuilds the six new binaries on a host with GCC, Clang/lld, Swift 6.2.1,
X11 development headers/libraries and libXtst. `tools/build_iso.py --help`
accepts a prepared root filesystem, kernel and EFI loader and does not require
mounting disks. `tools/audit_iso.py` audits the resulting media independently.

`assemble_rootfs.py` uses a curated inventory of already-installed Debian 13
packages and available manual binaries. It is not debootstrap/live-build and
is not an apt-validated full Debian installation. A fresh host needs these
inputs; this is not a claim of bit-for-bit whole-image reproducibility.
Set ZORIX_WORKDIR and ZORIX_LEGACY_DIR for assembly; never point the work
folder at a real system root. Run assembly only in a disposable build machine.

The source kit contains Zorix sources, not the complete corresponding source
for every third-party binary. See `THIRD_PARTY.md` and the package inventory.
Before public redistribution, arrange the applicable upstream source and
license obligations. No third-party proprietary license is overridden.
